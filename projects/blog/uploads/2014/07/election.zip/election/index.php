<?include "inc/load.php";?>
<html>
 <head>
  <?$ELEC->head();?>
 </head>
 <body>
  	<div class="content">
  		<form action="info.php" id="voterForm">
  			<h2>Class</h2>
  			<select name="class">
  				<?
  				for($i=5;$i < 11;$i++){
  					echo "<option name='$i'>$i</option>";
  				}
  				?>
  			</select>
  			<h2>Division</h2>
  			<select name="division">
  				<?
  				$divs = array(
  					1 => "A",
  					2 => "B",
  					3 => "C",
  					4 => "D"
  				);
  				for($i=1;$i < 5;$i++){
  					$n = $divs[$i];
  					echo "<option name='$n'>$n</option>";
  				}
  				?>
  			</select>
  			<h2>Roll Number</h2>
  			<input name="roll" type="number" placeholder="Roll Number" autocomplete="off" />
  			<div style="margin-top:15px;">
  				<button name="submit">Cast Your Vote</button>
  			</div>
  		</form>
  		<form action="vote.php" id="voteForm">
  			<div class="candidates">
  			 	<?$ELEC->showCandidates();?>
  			</div>
  			<button class="vote" name="vote" value="vote">Vote</button>
  		</form>
  		<div class='thankyou'>
  			<h1>Thank You</h1>
  			<p>Your vote was entered successfully.</p>
  		</div>
  	</div>
 </body>
</html>
