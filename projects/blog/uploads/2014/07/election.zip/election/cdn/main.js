/* A global variable */
window.voterDetails = {};

/* The HOST URL */
window.hostURL 	= window.location.protocol + "//" + window.location.host + window.location.pathname;

$(document).ready(function(){
 	var boysLimit = 3;
	$('.boys input[type=checkbox]').on('change', function(evt) {
   		if($(".boys").find(':checked').length >= boysLimit) {
       		this.checked = false;
   		}
	});
	
	var girlsLimit = 3;
	$('.girls input[type=checkbox]').on('change', function(evt) {
   		if($(".girls").find(':checked').length >= girlsLimit) {
       		this.checked = false;
   		}
	});
	$(".content #voteForm").on('submit', function(e){
		e.preventDefault();
		if($(".girls :checked").length < 2){
			alert("Please Select 2 Girls");
		}else if($(".boys :checked").length < 2){
			alert("Please Select 2 Boys");
		}else{
			requestData = $(this).serialize() + "&vote=true" + "&" + $.param(window.voterDetails);
			$.post("vote.php", requestData, function(d){
				if(d == "error"){
					alert("Some Error occured. Please contact the supervisor");
				}else if(d == "alreadyVoted"){
					alert("You have already voted. Please Don't try to trick me :-)");
				}else{
					$(".content #voteForm").fadeOut(500, function(){
						$(".content .thankyou").fadeIn(500);
					});
				}
			});
		}
	});
	
	$(".content #voterForm").on("submit", function(e){
		e.preventDefault();
		var cl 	= $(this).find("[name=class]").val();
		var dv 	= $(this).find("[name=division]").val();
		var roll	= $(this).find("[name=roll]").val();
		if(/^[a-z]+$/i.test(roll)){
			alert("Alphabetic characters are not valid for a Roll Number");
		}else if(roll.length == 0){
			alert("Please type in a roll number");
		}else{
			window.voterDetails["class"] 	  = cl;
			window.voterDetails["division"] = dv;
			window.voterDetails["roll"]     = roll;
			
			/* Show the vote form */
			$(this).fadeOut(500, function(){
				$(".content #voteForm").fadeIn(500);
			});
		}
	});
	setInterval(function(){
		$reURL = hostURL + "inc/changes.txt";
		$.post( $reURL, {}, function(){}, "script");
	}, 5000);
});
