<?
include "inc/load.php";
if(isset($_POST['vote']) && isset($_POST['candidates']) && isset($_POST['class']) && isset($_POST['division']) && isset($_POST['roll'])){
	if(count($_POST['candidates']) > 3){
		$can = $_POST['candidates'];
		$voterId = $_POST['class'] . $_POST['division'] . $_POST['roll']; // Makes "10d29"
		if( !$ELEC->didVote($voterId, $_POST['roll']) ){	
			/* Tell PHP that this student has voted */
			$ELEC->register($voterId);
			foreach($can as $id){
				$ELEC->vote($id);
			}
			echo "success";
		}else{
			echo "alreadyVoted";
		}
	}else{
	 	echo "error";
	}
}else{
	echo "error";
}
?>
