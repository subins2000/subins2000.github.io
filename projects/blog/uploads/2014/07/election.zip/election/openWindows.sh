#!/bin/bash
echo "Bash version ${BASH_VERSION}..."
for i in {1..30..1}
  do
     echo "Opening in System $i"
     sshpass -p "student" ssh student@192.168.10.$i "export DISPLAY=:0;firefox system1/election < /dev/null"  > /dev/null 2>&1 &
 done
