<?php
include "../inc/load.php";
if( isset($_POST['boysSubmit']) || isset($_POST['girlsSubmit']) ){
	$gender = isset($_POST['girlsSubmit']) ? "female" : "male";
	$genderValues = $_POST['genderVals'];
	
	foreach($_POST as $identifier => $newValue){
		if($oldValue != "boysSubmit"){
			$newGender = $genderValues[$identifier];
			$sql = $ELEC->dbh->prepare("UPDATE `electionCandidates` SET `candidateName` = ?, `gender` = ? WHERE `id` = ?");
			$sql->execute(array(
				$newValue,
				$newGender,
				$identifier,
			));
		}
	}
}

if( isset($_POST['addBoysSubmit']) || isset($_POST['addGirlsSubmit']) ){
	$gender = isset($_POST['addGirlsSubmit']) ? "female" : "male";
	foreach($_POST['candidates'] as $canName){
		$sql = $ELEC->dbh->prepare("INSERT INTO `electionCandidates` (`candidateName`, `gender`) VALUES(?, ?)");
		$sql->execute(array(
			$canName,
			$gender
		));
	}
}
?>
<html>
	<head>
		<?php $ELEC->head("Admin Panel");?>
	</head>
	<body>
		<div class="content" style="top:-40%;">
			<h2>Boys</h2>
			<p>Use the below form to change details of the <b>Boys</b> Candidates</p>
			<?php
			if($ELEC->isElection()){
				$sql = $ELEC->dbh->prepare("SELECT * FROM `electionCandidates` WHERE `gender`='male'");
 				$sql->execute();
 				echo "<form method='POST'>";
 					while($r = $sql->fetch()){
				 		echo "<div class='item'>";
					 		echo "<input type='text' size='30' name='{$r["id"]}' value='{$r["candidateName"]}' />";
					 		echo "<select name='genderVals[{$r["id"]}]' class='item' style='display:block;margin-left:20px;'>";
					 			echo "<option value='male' selected='selected'>Male</option>";
					 			echo "<option value='female'>Female</option>";
					 		echo "</select>";
					 	echo "</div>";
 					}
 					echo "<div class='item'>";
 						echo "<button name='boysSubmit'>Update Boys' Details</button>";
 					echo "</div>";
 				echo "</form>";
			}else{
			?>
				<form method="POST">
					<?php
					for($i=1;$i<5;$i++){
						echo "<div class='item'>";
							echo "<input name='candidates[]' placeholder='Candidate # $i' />";
						echo "</div>";
					}
					echo "<div class='item'>";
 						echo "<button name='addBoysSubmit'>Add Boys Candidates</button>";
 					echo "</div>";
					?>
				</form>
			<?php
			}
			?>
			<h2>Girls</h2>
			<p>Use the below form to change details of the <b>Girls</b> Candidates</p>
			<?php
			if($ELEC->isElection()){
				$sql = $ELEC->dbh->prepare("SELECT * FROM `electionCandidates` WHERE `gender`='female'");
 				$sql->execute();
 				echo "<form method='POST'>";
 					while($r = $sql->fetch()){
				 		echo "<div class='item'>";
					 		echo "<input type='text' size='30' name='{$r["id"]}' value='{$r["candidateName"]}' />";
					 		echo "<select class='item' name='genderVals[{$r["id"]}]' style='display:block;margin-left:20px;'>";
					 			echo "<option value='male'>Male</option>";
					 			echo "<option value='female' selected='selected'>Female</option>";
					 		echo "</select>";
					 	echo "</div>";
 					}
 					echo "<div class='item'>";
 						echo "<button name='girlsSubmit'>Update Girls' Details</button>";
 					echo "</div>";
 				echo "</form>";
			}else{
			?>
				<form method="POST">
					<?php
					for($i=1;$i<5;$i++){
						echo "<div class='item'>";
							echo "<input name='candidates[]' placeholder='Candidate # $i' />";
						echo "</div>";
					}
					echo "<div class='item'>";
 						echo "<button name='addGirlsSubmit'>Add Girls Candidates</button>";
 					echo "</div>";
					?>
				</form>
			<?php
			}
			?>
		</div>
		<style>
		.item{
			margin-top:10px;
		}
		</style>
	</body>
</html>
