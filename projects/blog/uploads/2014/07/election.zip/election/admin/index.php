<?php
include "../inc/load.php";
if( isset($_GET['action']) ){
	$ELEC->liveChange($_GET['action']);
}
?>
<html>
	<head>
		<?$ELEC->head("Admin Panel");?>
	</head>
	<body>
		<div class="content">
			<div>
				<a href="addCandidates.php" class="button">Candidates Enrollment</a>
			</div>
			<div style="margin-top:10px;">
				<a href="stats.php" class="button">Election Stats</a>
			</div>
			<h2>Other Tools</h2>
			<div style="margin-top:10px;">
				<a href="?action=reload">Reload Election Pages</a>
				<p style="margin-left:40px;">After Reload, a reset should be done !!!</p>
			</div>
			<div style="margin-top:10px;">
				<a href="?action=reset">Reset Live Actions</a>
			</div>
			
			<p style="margin-top:10px;">
				<?php
				if( isset($_GET['action']) ){
					echo "<h2>Requested for {$_GET['action']}</h1>";
				}
				?>
			</p>
		</div>
	</body>
</html>
