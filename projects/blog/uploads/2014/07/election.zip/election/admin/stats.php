<?php
include "../inc/load.php";
?>
<html>
	<head>
		<?php $ELEC->head("Admin Panel");?>
	</head>
	<body>
		<div class="content" style="top:-40%;width:600px;">
			<h2>Statistics</h2>
			<p>See the <b>live</b> results of the election</p>
			<h3>Candiate Result</h3>
			<img src="/inc/statsImage.php" />
			<h3>Standings</h3>
			<ol>
				<?php
				$sql = $ELEC->dbh->query("SELECT * FROM `electionCandidates` ORDER BY `votes` DESC");
				while($r=$sql->fetch()){
					echo "<li>{$r['candidateName']} - {$r['votes']}</li>";
				}
				?>
			</ol>
			<h3>Voters Details</h3>
			<p>The last 10 persons that have voted :</p>
			<ol>
				<?php
				$sql = $ELEC->dbh->query("SELECT * FROM `electionVoters` ORDER BY `id` DESC LIMIT 10");
				while($r=$sql->fetch()){
					echo "<li>{$r['voterId']}</li>";
				}
				?>
			</ol>
		</div>
	</body>
</html>
