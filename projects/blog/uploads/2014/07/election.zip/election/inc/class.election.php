<?
class Election {
 	public $dbh;
 	/* The last possible value of Roll Number in all the classes. Roll Number with the value given is the last person that can vote. Example : If it's 70, then in all the classess, Roll Numbers above 70 can't vote. */
 	private $maxRollNumber = 70;
 	
 	private $hostName = "http://192.168.10.1/election"; /* The host URL to access files from. Must be full path */
 	
 	public function __construct(){ 		
 		$username = "root";
 		$hostname = "localhost";
 		$password = "deepblue";
 		$database = "bethany_db";
 		$portname = 3306;
 		$this->dbh = new PDO("mysql:dbname=$database;host=$hostname;port=".$portname, $username, $password);
 		return true;
 	}
 	
 	public function head($title=""){
 		$title = $title == "" ? "Bethany Election 2014" : $title . " - Bethany Election 2014";
 		/* Display the Title */
 		echo "<title>$title</title>";
 		
 		/* Load the CSS, JS files */
 		echo "<link href='{$this->hostName}/cdn/main.css' rel='stylesheet'/>";
 		
 		/* jQuery */
 		echo "<script src='{$this->hostName}/cdn/jquery.js'></script>";
 		echo "<script src='{$this->hostName}/cdn/main.js'></script>";
 	}
 	
 	public function showCandidates(){
 		/* Boys Section */
 		$sql = $this->dbh->prepare("SELECT * FROM `electionCandidates` WHERE `gender`='male'");
 		$sql->execute();
 		echo "<div class='boys'>";
 			echo "<h2>Boys</h2>";
 			$this->candidates($sql->fetchAll());
 		echo "</div>";
 		
 		/* Girls Section */
 		$sql = $this->dbh->prepare("SELECT * FROM `electionCandidates` WHERE `gender`='female'");
 		$sql->execute();
 		echo "<div class='girls'>";
 			echo "<h2>Girls</h2>";
 			$this->candidates($sql->fetchAll());
 		echo "</div>";
 	}
 	
 	public function candidates($data){
 		foreach($data as $r){
 			$id   = $r['id'];
 			$name = $r['candidateName'];
 			echo "<div class='candidate'>";
 				echo "<input type='checkbox' name='candidates[]' value='$id' id='$id'/>";
 				echo "<label for='$id'>$name</label>";
 			echo "</div>";
 		}
 	}
 	
 	/* Check if the student has already voted */
 	public function didVote($id, $rollNumber){
 		$sql=$this->dbh->prepare("SELECT 1 FROM `electionVoters` WHERE `voterId` = ?");
		$sql->execute(array($id));
		return $sql->rowCount() == 0 && $rollNumber <= $this->maxRollNumber ? false : true;
 	}
 	
 	public function register($id){
 		if($id!=""){
 			$sql=$this->dbh->prepare("INSERT INTO `electionVoters` (`voterId`) VALUES (?)");
 			$sql->execute(array($id));
 		}
 	}
 	
 	public function vote($id){
 		if($id!=""){
 			$sql=$this->dbh->prepare("UPDATE `electionCandidates` SET `votes` = `votes` + 1 WHERE `id` = ?");
 			$sql->execute(array($id));
 		}
 	}
 	
 	/* See if Election Is Already Started */
 	public function isElection(){
 		$count = $this->dbh->query("SELECT COUNT(`id`) FROM `electionCandidates`")->fetchColumn();
 		return $count != 8 ? false:true;
 	}
 	
 	/* Make changes to the live election page */
 	public function liveChange( $type = "" ){
 		$file = "{$this->docRoot}/inc/changes.txt";
 		
 		$codes = array(
 			"reload" => "window.location = window.location;",
 			"reset"  => "1"
 		);
 		if( isset($codes[$type]) ){
 			file_put_contents($file, $codes[$type]);
 		}else{
 			return false;
 		}
 	}
}
?>
