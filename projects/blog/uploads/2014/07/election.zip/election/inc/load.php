<?
$root = realpath(dirname(__FILE__) . '/../');
include "$root/inc/class.election.php";
$ELEC = new Election();
$ELEC->docRoot = $root;
?>
