<?php
include "load.php";
    //Set content-type header
    header("Content-type: image/png");
    $data = array();

    //Include phpMyGraph5.0.php
    include_once 'graph.php';
    
    //Set config directives
    $cfg['title'] = 'Election Results';
    $cfg['width'] = 600;
    $cfg['height'] = 300;
    $cfg['value-font-size'] = 4;
    $cfg['key-font-size'] = 6;
    
    $sql = $ELEC->dbh->query("SELECT * FROM `electionCandidates`");
    while($r=$sql->fetch()){
    		$data[$r['candidateName']] = $r['votes'];
    }
    
    //Create phpMyGraph instance
    $graph = new phpMyGraph();

    //Parse
    $graph->parseVerticalColumnGraph($data, $cfg);
?> 
